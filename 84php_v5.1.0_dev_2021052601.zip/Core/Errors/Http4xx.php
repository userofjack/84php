<?php
require(dirname(__FILE__).'/../../Initial.php');
http_response_code(499);
Wrong::Report(['detail'=>'Error#M.0.1','code'=>'M.0.1','hide'=>FALSE]);