<?php
require(dirname(__FILE__).'/../Initial.php');
http_response_code(599);
Wrong::Report(['detail'=>'Error#M.0.3','code'=>'M.0.3','hide'=>FALSE]);