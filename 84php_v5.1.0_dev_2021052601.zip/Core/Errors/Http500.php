<?php
require(dirname(__FILE__).'/../Initial.php');
http_response_code(500);
Wrong::Report(['detail'=>'Error#M.0.2','code'=>'M.0.2','hide'=>FALSE]);