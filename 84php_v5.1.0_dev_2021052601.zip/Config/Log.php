<?php
$_SERVER['84PHP_CONFIG']['Log']=[
	'Interval'=>'H',
	'Access'=>FALSE
];