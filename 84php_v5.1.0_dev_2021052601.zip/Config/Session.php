<?php

$_SERVER['84PHP_CONFIG']['Session']=[
	//Session存储设置
	'System'=>[
		'save_handler'=>NULL,
		'cookie_lifetime'=>0,
		'gc_maxlifetime'=>1440,
		'gc_divisor'=>100,
		'gc_probability'=>1,
		'save_path'=>NULL
	],
	'TokenLimit'=>20,
	'TokenExpTime'=>600
];