<?php
$_SERVER['84PHP_CONFIG']['Ftp']=[
	//公共参数
	'Server'=>'',
	'User'=>'',
	'Password'=>'',
	'Port'=>21
];