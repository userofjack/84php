<?php
$_SERVER['84PHP_CONFIG']['Sms']=[
	'Timeout'=>15,

	'AliyunAccessKeyID'=>'',
	'AliyunAccessKeySecret'=>'',
	'AliyunSignName'=>'',
	'AliyunRegionId'=>'cn-hangzhou'
];