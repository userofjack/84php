<?php
$_SERVER['84PHP_CONFIG']['Img']=[
	'FontFile'=>'/Lib/ImgFont.ttf'
];