<?php
$_SERVER['84PHP_CONFIG']['Pay']=[
	'Timeout'=>15,
	
	'AliPid'=>'',
	'AliKey'=>'',
	'AliNotifyUrl'=>'',
	'AliReturnUrl'=>'',

	'WxAppid'=>'',
	'WxMchId'=>'',
	'WxKey'=>'',
	'WxNotifyUrl'=>'',
	'WxSceneInfo'=>[
		'h5_info'=>[
			'type'=>'',
			'wap_url'=>'',
			'wap_name'=>''
		]
	]
];