<?php
$_SERVER['84PHP_CONFIG']['Wrong']=[
	'Style'=>'AUTO',
	'Log'=>FALSE
];