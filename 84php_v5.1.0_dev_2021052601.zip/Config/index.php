<?php
require(dirname(__FILE__).'/../../Initial.php');
http_response_code(404);
Wrong::Report(['detail'=>'Error#M.0.0','code'=>'M.0.0','hide'=>FALSE]);