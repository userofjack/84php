<?php
$_SERVER['84PHP_CONFIG']['Tool']=[
	'HtmlTag'=>'br|p|span|i|b|u|strong|h\d|hr|table|thead|tbody|tfoot|caption|colgroup|col|ul|ol|li|em|sup|sub|tr|td|th|dt|dd|dl|pre',
	
];