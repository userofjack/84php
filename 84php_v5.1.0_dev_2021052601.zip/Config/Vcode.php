<?php
$_SERVER['84PHP_CONFIG']['Vcode']=[
	'FontFile'=>'/Lib/VcodeFont.ttf'
];