<?php

$_SERVER['84PHP_CONFIG']['Mysql']=[
	'Log'=>FALSE,

	'RW_Splitting'=>FALSE,

	'DbInfo'=>[
		'default'=>[
			'address'=>'localhost',
			'username'=>'root',
			'password'=>'0000',
			'dbname'=>'',
			'port'=>3306
		],

		'other'=>[
			'address'=>'',
			'username'=>'',
			'password'=>'',
			'dbname'=>'',
			'port'=>3306
		]
	]
];