<?php

$_SERVER['84PHP_CONFIG']['Db']=[
	'Log'=>FALSE,

	'RW_Splitting'=>FALSE,
	
	'DbType'=>'mysql',

	'DbInfo'=>[
		'default'=>[
			'address'=>'localhost',
			'username'=>'root',
			'password'=>'0000',
			'dbname'=>'',
			'port'=>3306,
			'charset'=>'utf8'
		],

		'other'=>[
			'address'=>'',
			'username'=>'',
			'password'=>'',
			'dbname'=>'',
			'port'=>3306,
			'charset'=>'utf8'
		]
	]
];