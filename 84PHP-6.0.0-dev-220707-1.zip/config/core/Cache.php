<?php
$_SERVER['84PHP']['Config']['Cache']=[
	'ExpTime'=>300
];