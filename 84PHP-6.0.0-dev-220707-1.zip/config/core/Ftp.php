<?php
$_SERVER['84PHP']['Config']['Ftp']=[
	//公共参数
	'Server'=>'',
	'User'=>'',
	'Password'=>'',
	'Port'=>21
];