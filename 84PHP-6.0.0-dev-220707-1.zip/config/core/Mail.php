<?php

$_SERVER['84PHP']['Config']['Mail']=[
	'Server'=>'',
	'Port'=>25,
	'UserName'=>'',
	'PassWord'=>'',
	'FromAddress'=>'',
	'FromName'=>''
];