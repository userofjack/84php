<?php
$_SERVER['84PHP']['Config']['Vcode']=[
	'FontFile'=>'/Lib/VcodeFont.ttf'
];