<?php
$_SERVER['84PHP']['Config']['Log']=[
	'Interval'=>'H',
	'Access'=>FALSE,
	'Level'=>'info'
];