<?php
$_SERVER['84PHP']['Config']['Sms']=[
	'Timeout'=>15,

	'AliyunAccessKeyID'=>'',
	'AliyunAccessKeySecret'=>'',
	'AliyunSignName'=>'',
	'AliyunRegionId'=>'cn-hangzhou'
];