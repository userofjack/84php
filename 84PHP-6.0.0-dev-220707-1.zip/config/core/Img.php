<?php
$_SERVER['84PHP']['Config']['Img']=[
	'FontFile'=>'/Lib/ImgFont.ttf'
];