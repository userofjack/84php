<?php
$_SERVER['84PHP']['Config']['Ip']=[
	'ExitProgream'=>TRUE
];